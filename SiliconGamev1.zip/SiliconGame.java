import java.io.File;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

// GRP-COSC2635 Michael Power s3162668
// SiliconGame is the main class of the game that extends from the
// Application class. It includes the GameControl object that
// manages the flow of the game.

public class SiliconGame extends Application
{
	private static Stage primaryStage;
	private static GameControl gameControl;
	
	// Display related constants and variables are initialised below;
	final static int DEFAULT_SCREEN_WIDTH = 800;
	final static int DEFAULT_SCREEN_HEIGHT = 600;
	private static int screenXInset = 150;
	private static int screenYInset = 100;
	
	// Used to set up a test window next to the main window
	private static Stage testStage = new Stage();
	private static final int TEST_WIDTH = 300;
	private static final int TEST_HEIGHT = 300;
	static Label testLabel = new Label();
	static Label dataLabel = new Label();
	static Label data2Label = new Label();
	
	public void start(Stage stage)
	{
		SiliconGame.primaryStage = stage;
		gameControl = new GameControl();
		
		// Set values to determine window width and height.
		primaryStage.setMaxHeight(DEFAULT_SCREEN_HEIGHT);
		primaryStage.setMaxWidth(DEFAULT_SCREEN_WIDTH);
		primaryStage.setMinHeight(DEFAULT_SCREEN_HEIGHT);
		primaryStage.setMinWidth(DEFAULT_SCREEN_WIDTH);
		   
		// A separate window provides output data to help with testing
		// the interaction between mouse and card.
		testStage.setTitle("Test Output");
		testStage.setMaxHeight(TEST_HEIGHT);
		testStage.setMaxWidth(TEST_WIDTH);
		testStage.setMinHeight(TEST_HEIGHT);
		testStage.setMinWidth(TEST_WIDTH);
		testStage.setScene(testScene());
		// Place the test stage next to the main window on the right
		testStage.setX(screenXInset + DEFAULT_SCREEN_WIDTH + 20);
		testStage.setY(screenYInset);
		
        primaryStage.setTitle("Silicon");
		primaryStage.setX(screenXInset);
		primaryStage.setY(screenYInset);
		
		// Setup the title screen and set the stage
		primaryStage.setScene(titleScene());
		
		// Show each stage/window and ensure primaryStage is active
		primaryStage.show();
		testStage.show();
		primaryStage.toFront();
		   
		// If the main window is closed, close the test window as well.
		primaryStage.setOnCloseRequest(e -> testStage.close());
   }
	
   // The following method sets up the title screen at the beginning
   // of the game
   static Scene titleScene()
   {
	   StackPane pane = new StackPane();
	   // The program must find the frigate image on the file system
	   try
	   {
	       Image backGround = new Image("images/frigate.png");
	       ImageView imageView = new ImageView(backGround);
	       imageView.setFitWidth(DEFAULT_SCREEN_WIDTH);
	       imageView.setFitHeight(DEFAULT_SCREEN_HEIGHT);
	       pane.getChildren().add(imageView);
	   } catch (Exception ex)
	   {
	       System.out.println("Unable to load image - check file system.");
	   }
	   
	   VBox titleButtons = new VBox(50);
	   titleButtons.setAlignment(Pos.CENTER);
	   titleButtons.setMinHeight(300);
	   titleButtons.setMinWidth(300);
	   
	   // The buttons represent user options at the beginning of the game
	   Button newGame = new Button("Start New Game");
	   titleButtons.getChildren().add(newGame);
	   Button loadGame = new Button("Load Game");
	   titleButtons.getChildren().add(loadGame);
	   Button highScores = new Button("High Scores");
	   titleButtons.getChildren().add(highScores);
	   Button quitGame = new Button("Quit Game");
	   titleButtons.getChildren().add(quitGame);
	   
	   // Assign actions to each of the title screen buttons
	   newGame.setOnAction(e ->
	   {
		   dataLabel.setText("Start New Game selected");
		   GameBoard gameBoard = new GameBoard(primaryStage, gameControl);
	   });
	   loadGame.setOnAction(e ->
	   {
		   dataLabel.setText("Load Game selected");
	   });
	   highScores.setOnAction(e ->
	   {
		   dataLabel.setText("High Scores selected");
		   primaryStage.setScene(SiliconGame.highScoreScene());
	   });
	   quitGame.setOnAction(e ->
	   {
		   dataLabel.setText("Quit Game selected");
		   testStage.close();
		   primaryStage.close();
	   });
	   
	   pane.getChildren().add(titleButtons);
	   Scene scene = new Scene(pane);
	   return scene;
   }
   
   // The following method sets up a scene to display the high
   // score table
   static Scene highScoreScene()
   {
	   StackPane pane = new StackPane();
	   
	   // Attempt to load the high score background
	   try
	   {
	       Image backGround = new Image("images/sunset.jpg");
	       ImageView imageView = new ImageView(backGround);
	       imageView.setFitWidth(DEFAULT_SCREEN_WIDTH);
	       imageView.setFitHeight(DEFAULT_SCREEN_HEIGHT);
	       pane.getChildren().add(imageView);
	   } catch (Exception ex)
	   {
	       System.out.println("Unable to load image - check file system.");
	   }
	   
	   
	   
	   VBox highScores = new VBox(50);
	   highScores.setAlignment(Pos.CENTER);
	   highScores.setMinWidth(300);
	   highScores.setMinHeight(300);
	   
	   String high_score_data = "default";
	   try
	   {
		   Scanner scanner = new Scanner(new File("bin/data/high_scores.txt"));
		   high_score_data = scanner.nextLine();
		   scanner.close();

	   String[] h_values = high_score_data.split(",");
	   
	   Label highScore1 = new Label(h_values[0] + " " + h_values[2]);
	   highScore1.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore1);
	   Label highScore2 = new Label(h_values[3] + " " + h_values[5]);
	   highScore2.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore2);
	   Label highScore3 = new Label(h_values[6] + " " + h_values[8]);
	   highScore3.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore3);
	   Label highScore4 = new Label(h_values[9] + " " + h_values[11]);
	   highScore4.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore4);
	   Label highScore5 = new Label(h_values[12] + " " + h_values[14]);
	   highScore5.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore5);
	   }catch(Exception ex)
	   {
	      System.out.println("Unable to load high scores - file error");
	      Label error = new Label("Unable to load high scores - file error");
	      error.setStyle("-fx-font: 20 Arial");
	      highScores.getChildren().add(error);
	   }
	   
	   Button returnMainMenu = new Button("Return to Main Menu");
	   returnMainMenu.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(returnMainMenu);
	   returnMainMenu.setOnAction(e->
	   {
	      data2Label.setText("Return button pressed.");
	      primaryStage.setScene(titleScene());
	   });
	   
	   pane.getChildren().add(highScores);
	   Scene scene = new Scene(pane);
	   return scene;
   }
   
   
	
   // The following method sets up a test window scene to evaluate events
   // while running the program. Output data can be sent to the labels
   // 'dataLabel' and 'data2Label'
   Scene testScene()
   {
      StackPane pane = new StackPane();
	  VBox testVBox = new VBox();
	  testVBox.setSpacing(40);
	  testVBox.setAlignment(Pos.CENTER);
		   
	  testLabel.setText("Test Output");
	  testLabel.setStyle("-fx-font: 20 Arial");
	  testVBox.getChildren().add(testLabel);
	  dataLabel.setText("data1");
	  dataLabel.setStyle("-fx-font: 20 Arial");
	  testVBox.getChildren().add(dataLabel);
	  data2Label.setText("data2");
	  data2Label.setStyle("-fx-font: 20 Arial");
	  testVBox.getChildren().add(data2Label);
		   
	  pane.getChildren().add(testVBox);
	  Scene scene = new Scene(pane);
	  scene.setFill(Color.AZURE);
		   
	  return scene;
   }
   
   // The main method launches the program
   public static void main(String[] args)
   {
      Application.launch(args);
   }
}
