import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

// GRP-COSC2635 Michael Power s3162668
// SiliconGame is the main class of the game that extends from the
// Application class. It includes the GameControl object that
// manages the flow of the game.

public class SiliconGame extends Application
{
	private static Stage primaryStage;
	private static GameControl gameControl;
	
	// Display related constants and variables are initialised below;
	final static int DEFAULT_SCREEN_WIDTH = 800;
	final static int DEFAULT_SCREEN_HEIGHT = 600;
	private static int screenXInset = 150;
	private static int screenYInset = 100;
	
	// Used to set up a test window next to the main window
	private static Stage testStage = new Stage();
	private static final int TEST_WIDTH = 300;
	private static final int TEST_HEIGHT = 300;
	static Label testLabel = new Label();
	static Label dataLabel = new Label();
	static Label data2Label = new Label();
	
	public void start(Stage stage)
	{
		SiliconGame.primaryStage = stage;
		gameControl = new GameControl();
		
		// Set values to determine window width and height.
		primaryStage.setMaxHeight(DEFAULT_SCREEN_HEIGHT);
		primaryStage.setMaxWidth(DEFAULT_SCREEN_WIDTH);
		primaryStage.setMinHeight(DEFAULT_SCREEN_HEIGHT);
		primaryStage.setMinWidth(DEFAULT_SCREEN_WIDTH);
		   
		// A separate window provides output data to help with testing
		// the interaction between mouse and card.
		testStage.setTitle("Test Output");
		testStage.setMaxHeight(TEST_HEIGHT);
		testStage.setMaxWidth(TEST_WIDTH);
		testStage.setMinHeight(TEST_HEIGHT);
		testStage.setMinWidth(TEST_WIDTH);
		testStage.setScene(testScene());
		// Place the test stage next to the main window on the right
		testStage.setX(screenXInset + DEFAULT_SCREEN_WIDTH + 20);
		testStage.setY(screenYInset);
		
        primaryStage.setTitle("Silicon");
		primaryStage.setX(screenXInset);
		primaryStage.setY(screenYInset);
		
		// Setup the title screen and set the stage
		primaryStage.setScene(titleScene());
		
		// Show each stage/window and ensure primaryStage is active
		primaryStage.show();
		testStage.show();
		primaryStage.toFront();
		   
		// If the main window is closed, close the test window as well.
		primaryStage.setOnCloseRequest(e -> testStage.close());
   }
	
   // The following method sets up the title screen at the beginning
   // of the game
   static Scene titleScene()
   {
	   StackPane pane = new StackPane();
	   // The program must find the frigate image on the file system
	   try
	   {
	       Image backGround = new Image("images/frigate.png");
	       ImageView imageView = new ImageView(backGround);
	       imageView.setFitWidth(DEFAULT_SCREEN_WIDTH);
	       imageView.setFitHeight(DEFAULT_SCREEN_HEIGHT);
	       pane.getChildren().add(imageView);
	   } catch (Exception ex)
	   {
	       System.out.println("Unable to load image - check file system.");
	   }
	   
	   VBox titleButtons = new VBox(50);
	   titleButtons.setAlignment(Pos.CENTER);
	   titleButtons.setMinHeight(300);
	   titleButtons.setMinWidth(300);
	   
	   // The buttons represent user options at the beginning of the game
	   Button newGame = new Button("Start New Game");
	   titleButtons.getChildren().add(newGame);
	   Button loadGame = new Button("Load Game");
	   titleButtons.getChildren().add(loadGame);
	   Button highScores = new Button("High Scores");
	   titleButtons.getChildren().add(highScores);
	   Button quitGame = new Button("Quit Game");
	   titleButtons.getChildren().add(quitGame);
	   
	   // Assign actions to each of the title screen buttons
	   newGame.setOnAction(e ->
	   {
		   dataLabel.setText("Start New Game selected");
		   GameBoard gameBoard = new GameBoard(primaryStage, gameControl);
	   });
	   loadGame.setOnAction(e ->
	   {
		   dataLabel.setText("Load Game selected");
	   });
	   highScores.setOnAction(e ->
	   {
		   dataLabel.setText("High Scores selected");
		   primaryStage.setScene(SiliconGame.highScoreScene());
	   });
	   quitGame.setOnAction(e ->
	   {
		   dataLabel.setText("Quit Game selected");
		   testStage.close();
		   primaryStage.close();
	   });
	   
	   pane.getChildren().add(titleButtons);
	   Scene scene = new Scene(pane);
	   return scene;
   }
   
   // The following method sets up a scene to display the high
   // score table
   static Scene highScoreScene()
   {
	   StackPane pane = new StackPane();
	   
	   // Attempt to load the high score background
	   try
	   {
	       Image backGround = new Image("images/sunset.jpg");
	       ImageView imageView = new ImageView(backGround);
	       imageView.setFitWidth(DEFAULT_SCREEN_WIDTH);
	       imageView.setFitHeight(DEFAULT_SCREEN_HEIGHT);
	       pane.getChildren().add(imageView);
	   } catch (Exception ex)
	   {
	       System.out.println("Unable to load image - check file system.");
	   }
	   
	   
	   
	   VBox highScores = new VBox(50);
	   highScores.setAlignment(Pos.CENTER);
	   highScores.setMinWidth(300);
	   highScores.setMinHeight(300);
	   
	   String high_score_data = "default";
	   try
	   {
		   Scanner scanner = new Scanner(new File("bin/data/high_scores.txt"));
		   high_score_data = scanner.nextLine();
		   scanner.close();

	   String[] h_values = high_score_data.split(",");
	   
	   Label highScore1 = new Label(h_values[0] + " " + h_values[2]);
	   highScore1.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore1);
	   Label highScore2 = new Label(h_values[3] + " " + h_values[5]);
	   highScore2.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore2);
	   Label highScore3 = new Label(h_values[6] + " " + h_values[8]);
	   highScore3.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore3);
	   Label highScore4 = new Label(h_values[9] + " " + h_values[11]);
	   highScore4.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore4);
	   Label highScore5 = new Label(h_values[12] + " " + h_values[14]);
	   highScore5.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(highScore5);
	   }catch(Exception ex)
	   {
	      System.out.println("Unable to load high scores - file error");
	      Label error = new Label("Unable to load high scores - file error");
	      error.setStyle("-fx-font: 20 Arial");
	      highScores.getChildren().add(error);
	   }
	   
	   Button returnMainMenu = new Button("Return to Main Menu");
	   returnMainMenu.setStyle("-fx-font: 20 Arial");
	   highScores.getChildren().add(returnMainMenu);
	   returnMainMenu.setOnAction(e->
	   {
	      data2Label.setText("Return button pressed.");
	      primaryStage.setScene(titleScene());
	   });
	   
	   pane.getChildren().add(highScores);
	   Scene scene = new Scene(pane);
	   return scene;
   }
   
   
	
   // The following method sets up a test window scene to evaluate events
   // while running the program. Output data can be sent to the labels
   // 'dataLabel' and 'data2Label'
   Scene testScene()
   {
      StackPane pane = new StackPane();
	  VBox testVBox = new VBox();
	  testVBox.setSpacing(40);
	  testVBox.setAlignment(Pos.CENTER);
		   
	  testLabel.setText("Test Output");
	  testLabel.setStyle("-fx-font: 20 Arial");
	  testVBox.getChildren().add(testLabel);
	  dataLabel.setText("data1");
	  dataLabel.setStyle("-fx-font: 20 Arial");
	  testVBox.getChildren().add(dataLabel);
	  data2Label.setText("data2");
	  data2Label.setStyle("-fx-font: 20 Arial");
	  testVBox.getChildren().add(data2Label);
		   
	  pane.getChildren().add(testVBox);
	  Scene scene = new Scene(pane);
	  scene.setFill(Color.AZURE);
		   
	  return scene;
   }
   
   // The main method launches the program
   public static void main(String[] args)
   {
      Application.launch(args);
   }
}

//GRP-COSC2635 Michael Power s3162668
//The GameBoard class represents the main game area. It is
//initiated when the user requests to play a new game. The data for
//this scene is encapsulated in order to limit complication with
//coding in the SiliconGame class

class GameBoard
{
	private Scene scene;
	private Group group;
	private Stage primaryStage;
	private GameControl gameControl;
	private Card[] deck;
	
	// Variable used to represent views of the deck
	private int selectedCard;
	private ImageView selectedCardView;
	private Location selectedCardLocation;
	private boolean selectToggle = false;
	
	private int mainDeckXCoord = 600;
	private int mainDeckYCoord = 150;
	
	private double cardXOffset = 45.0;
	private double cardYOffset = 35.0;
	private double cardHorizontalXEdge = 0.0;
	private double cardVerticalYEdge = 13.0;
	private double stageLeftOffset = 120.0;
	private double stageDownOffset = 130.0;
	
public GameBoard(Stage stage, GameControl gC)
{
	   // Import references to the main stage and GameControl object
	   primaryStage = stage;
	   gameControl = gC;
	   gameControl.newGame();
	   deck = gameControl.getGameState().getDeck();
	   primaryStage.setScene(sceneSetup());
}

Scene sceneSetup()
{
	   StackPane pane = new StackPane();
	   
	   // Attempt to load background image
	   try
	   {
		   Image image = new Image("images/background.jpg");
		   ImageView view = new ImageView(image);
		   view.fitWidthProperty().bind(primaryStage.widthProperty());
		   view.fitHeightProperty().bind(primaryStage.heightProperty());
		   pane.getChildren().add(view);
	   }catch(Exception ex)
	   {
		   System.out.println("Unable to load image from file - check folder.");
	   }
	   
	   group = new Group();
	   group.setManaged(false);
	   pane.getChildren().add(group);
	   
	   // Display the deck of cards on the table in order to allow
	   // the test player to move around cards. Left click to pick
	   // up a card and right click to change the orientation
	   // from horizontal to vertical
	   ImageView[] cardViews = new ImageView[deck.length];
	   Location[] cardLocations = new Location[deck.length];
	   for(int i = 0; i < deck.length; i++)
	   {
		   cardLocations[i] = deck[i].getLocation();
		   cardLocations[i].setXCoord(mainDeckXCoord);
		   cardLocations[i].setYCoord(mainDeckYCoord);
		   cardViews[i] = new ImageView(deck[i].getImage());
		   if (!cardLocations[i].getHorizontal()) cardViews[i].setRotate(90);
		   cardViews[i].setX(cardLocations[i].getXCoord());
		   cardViews[i].setY(cardLocations[i].getYCoord());
		   // Add each card to the cardGroup
		   group.getChildren().add(cardViews[i]);
	   }
	   
	   // Point to the ImageView and Location on top of the deck
	   selectedCard = 0;
	   selectedCardView = cardViews[selectedCard];
	   selectedCardLocation = cardLocations[selectedCard];
	   // Ensure selected card is on top of the others
	   group.getChildren().remove(cardViews[selectedCard]);
	   group.getChildren().add(cardViews[selectedCard]);
	   
	   // The first card is given an EventHandler
	   selectedCardView.setOnMouseClicked(e ->
	   {
		   // Check if the left button was pressed
		   if(e.getButton().equals(MouseButton.PRIMARY))
		   {
		      handleLeftClick();
		      if(!selectToggle)
		      {
		    	  // Organise EventHandlers for the next cards
		    	  manageMouseClick(cardViews);
		      }
		   }
		   
		   // Check if the right mouse button was pressed and
		   // that the current card has already been clicked on
		   if(selectToggle && e.getButton().equals(MouseButton.SECONDARY))
		   {
			   handleRightClick();
		   }
	   });
	   
	   // Add a button that will allow us to return to the main screen
	   // during the testing phase of the project.
	   Button returnButton = new Button("Return to Main Menu");
	   returnButton.setStyle("-fx-font: 20 Arial");
	   returnButton.setOnAction(e ->
	   {
		   primaryStage.setScene(SiliconGame.titleScene());
	   });
	   returnButton.setTranslateY(primaryStage.getHeight() / 3.0);
	   pane.getChildren().add(returnButton);
	   
	   scene = new Scene(pane);
	   return scene;
}

// This method manages the assigning of a new Event Handler to a card view
void manageMouseClick(ImageView[] cardViews)
{
   cardViews[selectedCard].setOnMouseClicked(null);
   selectedCard++;
   
   // If we have not reached the end of the deck then make a
   // new Event Handler for the next card.
   if(selectedCard < deck.length)
   {
 	  selectedCardLocation = deck[selectedCard].getLocation();
 	  selectedCardView = cardViews[selectedCard];
 	  
 	  // Ensure new selected card is on the top
 	  group.getChildren().remove(selectedCardView);
 	  group.getChildren().add(selectedCardView);
 	  
 	  selectedCardView.setOnMouseClicked(e ->
 	  {
 		  if(e.getButton().equals(MouseButton.PRIMARY))
 		  {
 			 handleLeftClick();
 			 if(!selectToggle)
 			 {
 				 // The method is recursively called for each new card
 				 manageMouseClick(cardViews);
 			 }
 			 
 		  }
 		  
 		  // Ensure right mouse button only working if the new
 		  // card has already been clicked on
 		  if(selectToggle && e.getButton().equals(MouseButton.SECONDARY))
 		  {
 		     handleRightClick();
 		  }
 	  });
 	  
   } else
   {
 	  // The last card has been deselected.
 	  SiliconGame.dataLabel.setText("No more cards to choose.");
 	  SiliconGame.data2Label.setText("");
   } 
}

// Method for handling the left click of a card
void handleLeftClick()
{
   if(selectToggle)
	  {
	  // Card was deselected
	  scene.setOnMouseMoved(null);
   SiliconGame.dataLabel.setText("Left Button clicked");
   SiliconGame.data2Label.setText("Card deselected");
   
   try
   {
 	  // Add a new ImageView representing the flip side of the card
 	  // showing the name of the card.
 	  selectedCardLocation.setXCoord((int)selectedCardView.getX());
 	  selectedCardLocation.setYCoord((int)selectedCardView.getY());
 	  
 	  selectedCardView = new ImageView(new Image("images/card_blank.png"));
 	  if(!selectedCardLocation.getHorizontal())
 	     selectedCardView.setRotate(90);
 	  selectedCardView.setX(selectedCardLocation.getXCoord());
 	  selectedCardView.setY(selectedCardLocation.getYCoord());
 	  // After determining the location and orientation, the ImageView
 	  // can be added to the cardGroup
 	  group.getChildren().add(selectedCardView);
 	  
 	  // Create a label depicting the name of the card
 	  // to be placed upon the new ImageView.
 	  Label cardLabel = new Label();
 	  cardLabel.setText(deck[selectedCard].getName());
 	  cardLabel.setTranslateX(selectedCardLocation.getXCoord() + 10.0);
 	  cardLabel.setTranslateY(selectedCardLocation.getYCoord() + 30.0);
 	  if(!selectedCardLocation.getHorizontal())
  	     cardLabel.setRotate(90);
 	  group.getChildren().add(cardLabel);
 	  
   } catch(Exception ex)
   {
 	  System.out.println("Unable to load image from file - check folder.");
   }
		 
	  selectToggle = false;
	  } else
	  {
	     // Card was selected
		 SiliconGame.dataLabel.setText("Left Button clicked");
		 SiliconGame.data2Label.setText(deck[selectedCard].getName() + " selected");
		 group.getChildren().remove(selectedCardView);
		 group.getChildren().add(selectedCardView);
		 // Now create another EventHandler that detects mouse
		 // movement - card coordinates are plotted to follow the
		 // mouse cursor
		 scene.setOnMouseMoved(event ->
		 {
		    // Setting limits for card movement to the table.
		    double xVal = event.getX() - cardXOffset;
		    double yVal = event.getY() - cardYOffset;
		    if (selectedCardLocation.getHorizontal())
		    {
			   if (xVal < cardHorizontalXEdge)
			      xVal = cardHorizontalXEdge;
			   if(xVal > SiliconGame.DEFAULT_SCREEN_WIDTH - stageLeftOffset)
				  xVal = SiliconGame.DEFAULT_SCREEN_WIDTH - stageLeftOffset;
			      selectedCardView.setX(xVal);
			      if (yVal < 0.0) yVal = 0.0;
			      if(yVal > SiliconGame.DEFAULT_SCREEN_HEIGHT -
				     (stageDownOffset - 13.0))
					 yVal = SiliconGame.DEFAULT_SCREEN_HEIGHT -
					    (stageDownOffset - 13.0);
					 selectedCardView.setY(yVal);
		    	  } else
		    	  {
			         if (xVal < -13.0)
			    	    xVal = -13.0;
					 if(xVal > SiliconGame.DEFAULT_SCREEN_WIDTH -
					    (stageLeftOffset - 13.0))
					    xVal = SiliconGame.DEFAULT_SCREEN_WIDTH -
					    (stageLeftOffset - 13.0);
					 selectedCardView.setX(xVal);
			    	 if (yVal < cardVerticalYEdge) yVal =
			    	    cardVerticalYEdge;
					 if(yVal > SiliconGame.DEFAULT_SCREEN_HEIGHT -
					    stageDownOffset)
					    yVal = SiliconGame.DEFAULT_SCREEN_HEIGHT -
					       stageDownOffset;
					 selectedCardView.setY(yVal);
		          }
		     });
	     selectToggle = true;
   }
}

void handleRightClick()
{
	   if(selectedCardLocation.getHorizontal())
	   {
		   SiliconGame.dataLabel.setText("Right Button clicked");
		   SiliconGame.data2Label.setText("Switch to vertical");
		   selectedCardLocation.setHorizontal(false);
		   selectedCardView.setRotate(90);
	   }else
	   {
		   SiliconGame.dataLabel.setText("Right Button clicked");
		   SiliconGame.data2Label.setText("Switch to horizontal");
		   selectedCardLocation.setHorizontal(true);
		   selectedCardView.setRotate(0);
	   }
}
}


//GRP-COSC2635 Michael Power s3162668
//The GameControl class acts as a bridge between the data of the card
//game and the various display functions. It manages the flow of
//activity during the game.

class GameControl
{
private GameState gameState;
private GameRules gameRules;
	
public GameControl()
{
	   gameRules = new GameRules();
	   
	   //newGame();
}

void newGame()
{
	   gameState = new GameState(gameRules.getNumberOfPlayers(),
	      gameRules.getNumberOfCards());
	   
	   initialisePlayers();
	   
	   // Set up a deck of cards to be used in the gameState for
	   // testing purposes.
	   Card[] deck = gameState.getDeck();
	   deck = initialiseDeck(deck);
	   shuffleDeck(deck);
	   gameState.setDeck(deck);
}

GameState getGameState()
{
	   return gameState;
}

// This method is used to initialise the players for the game.
// Configured for testing purposes.
void initialisePlayers()
{
	   for(int i = 0; i < gameRules.getNumberOfPlayers(); i++)
	   {
		   Player player = new Player();
		   player.setName("Player" + (i + 1));
		   gameState.addPlayer(i, player);
	   }
}

// This method is used to initialise the cards for the game.
// Configured for testing purposes. Assumes a deck of 54 cards
// while in testing phase.
Card[] initialiseDeck(Card[] deck)
{
   if(deck.length != 54)
   {
      System.out.println("Cannot set up the deck - wrong size.");
      return deck;
   }
	  
	  // Set up names for each card
	  String[] suits = new String[]{" of diamonds", " of clubs",
	     " of spades", " of hearts"};
	   
	  for(int i = 0; i < 4; i++)
	  {
		 deck[0 + i * 13] = new Card("Ace" + suits[i]);
		 deck[1 + i * 13] = new Card("Two" + suits[i]);
		 deck[2 + i * 13] = new Card("Three" + suits[i]);
		 deck[3 + i * 13] = new Card("Four" + suits[i]);
		 deck[4 + i * 13] = new Card("Five" + suits[i]);
	     deck[5 + i * 13] = new Card("Six" + suits[i]);
		 deck[6 + i * 13] = new Card("Seven" + suits[i]);
		 deck[7 + i * 13] = new Card("Eight" + suits[i]);
		 deck[8 + i * 13] = new Card("Nine" + suits[i]);
		 deck[9 + i * 13] = new Card("Ten" + suits[i]);
		 deck[10 + i * 13] = new Card("Jack" + suits[i]);
		 deck[11 + i * 13] = new Card("Queen" + suits[i]);
		 deck[12 + i * 13] = new Card("King" + suits[i]);
	  }
	  deck[52] = new Card("Joker1");
	  deck[53] = new Card("Joker2");
	  
	  return deck;
}

// Shuffles the deck of Cards
Card[] shuffleDeck(Card[] deck)
{
	   Card tempCard;
	   for(int i = 0; i < deck.length; i++)
	   {
		   tempCard = deck[i];
		   int randomCard = (int)(Math.random() * deck.length);
		   deck[i] = deck[randomCard];
		   deck[randomCard] = tempCard;
		   
	   }
	   
	   return deck;
}

// The following method prints out the card names
void printCardNames(Card[] deck)
{
	   for(Card card: deck)
	   {
		   System.out.println(card.getName());
	   }
}
}

//GRP-COSC2635 Michael Power s3162668
//The PlayerMove class is intended to model a single player's
//move in the card game. The player can buy a card and place
//in at a location on the card table, can attempt a take-over
//of another player's card or can choose to convert money
//into research.
class PlayerMove
{
private String moveType;
private Location location;
private int cost;
private Card attackCard;
private int research;

// The following three constructors represent the three different move
// types.
public PlayerMove(String moveType, Location location, int cost)
{
	   System.out.println("PlayerMove object was created.");
	   this.moveType = moveType;
	   this.location = location;
	   this.cost = cost;
}

public PlayerMove(String moveType, Card attackCard)
{
	   this.attackCard = attackCard;
}

public PlayerMove(String moveType, int research)
{
	   this.research = research;
}

String getMoveType()
{
	   return moveType;
}

Location getLocation()
{
	   return location;
}

int getCost()
{
	   return cost;
}

Card getAttackCard()
{
	   return attackCard;
}

int getResearch()
{
	   return research;
}
}

//GRP-COSC2635 Michael Power s3162668
//The GameState class is intended to embody the current state of
//play in the card game - data is managed by the GameControl class.

class GameState
{
private Player[] players;
private Card[] deck;
private int gameRound;
private int playerTurn;
Image cardFlipSide;

public GameState(int numberOfPlayers, int deckSize)
{
	   // Initialise main variables for the game
	   players = new Player[numberOfPlayers];
	   deck = new Card[deckSize];
	   gameRound = 1;
	   // Point the playerTurn variable to the start of the players array
	   playerTurn = 0;
}

Player[] getPlayers()
{
	   return players;
}

Card[] getDeck()
{
	   return deck;
}

int getGameRound()
{
	   return gameRound;
}

int getPlayerTurn()
{
	   return playerTurn;
}

void addPlayer(int playerNumber, Player player)
{
	   try
	   {
		   players[playerNumber] = player;
	   }catch(Exception ex)
	   {
		   System.out.println("Unable to add player to the game.");
	   }
}

void setDeck(Card[] deck)
{
   this.deck = deck;
}

}

//GRP-COSC2635 Michael Power s3162668
//The player class is used to represent a player in the card game
//whether human or computer controlled.

class Player
{
private String name;
private boolean human;
private int money = 0;
private int research = 0;
private int moduleLevel = 0;
private ArrayList<Card> cards = new ArrayList<Card>();

public Player()
{
	   
}

String getName()
{
	   return name;
}

boolean getHuman()
{
	   return human;
}

int getMoney()
{
	   return money;
}

int getResearch()
{
	   return research;
}

int getModuleLevel()
{
	   return moduleLevel;
}

Card getPlayerCard(int index)
{
	   return cards.get(index);
}

void setName(String name)
{
	   this.name = name;
}

void setMoney(int money)
{
	   this.money = money;
}

void setResearch(int research)
{
	   this.research = research;
}

void upgradeModuleLevel()
{
	   moduleLevel++;
}

void addCard(Card newCard)
{
	   cards.add(newCard);
}
}

//GRP-COSC2635 Michael Power s3162668
//The following class is intended to encapsulate aspects of the
//game rules. The variables/methods of this class represent a
//reference point for the GameController class in managing the
//game.
class GameRules
{
final private int NUMBER_OF_PLAYERS = 4;
final private int NUMBER_OF_CARDS = 54;

public GameRules()
{
	   
}

int getNumberOfPlayers()
{
	   return NUMBER_OF_PLAYERS;
}

int getNumberOfCards()
{
	   return NUMBER_OF_CARDS;
}
}


//GRP-COSC2635 Michael Power s3162668
//Card class used to represent the details of a
//a card such as name and revenue. Also holds a
//location value in relation to the card table.
class Card
{
private String name;
private int revenue = 0;
private int research = 0;
private String cardType = "default";
private Image display;
private Location location = new Location();

public Card(String name)
{
	   this.name = name;
	   
	   try
	   {
       display = new Image("images/card_default.png");
	   } catch (Exception ex)
	   {
		   System.out.println("Failed to load card image - check " +
	          "file system");
	   }
}

String getName()
{
	   return name;
}

int getRevenue()
{
	   return revenue;
}

int getResearch()
{
	   return research;
}

String getCardType()
{
	   return cardType;
}

Image getImage()
{
	   return display;
}

Location getLocation()
{
	   return location;
}

}


//GRP-COSC2635 Michael Power s3162668
//Location class used to represent the location of
//a card on the card table.
class Location
{
private int xCoord = 500;
private int yCoord = 380;
private boolean horizontal = true;

public Location()
{
	   
}

int getXCoord()
{
	   return xCoord;
}

int getYCoord()
{
	   return yCoord;
}

boolean getHorizontal()
{
	   return horizontal;
}

void setXCoord(int xCoord)
{
	   this.xCoord = xCoord;
}

void setYCoord(int yCoord)
{
	   this.yCoord = yCoord;
}

void setHorizontal(boolean horizontal)
{
	   this.horizontal = horizontal;
}
}







