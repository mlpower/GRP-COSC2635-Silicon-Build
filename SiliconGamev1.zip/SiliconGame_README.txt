
21/03/19
GRP-COSC2635 Michael Power s3162668
SiliconGame version1
-When copying into Eclipse - ensure that both the images and data folders are located in the bin directory of your project. With the main file 'SiliconGame.java' you can try to import this to your project or simply create a new class in your project called 'SiliconGame' and copy and paste the contents of the java file

-If you are on a computer that uses Java SE 8 and you wish to compile and run from the command line, use:

javac SiliconGame.java

java SiliconGame

