
20/03/19
GRP-COSC2635 Michael Power s3162668
SiliconGame version1
-When copying into Eclipse - ensure that both the images and data folders are located in the bin directory of your project.
-Launch from the SiliconGame class.